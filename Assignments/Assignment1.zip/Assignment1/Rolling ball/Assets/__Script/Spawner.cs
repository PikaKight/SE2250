using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject smallItem, medItem, largeItem;
    
    private int smallItemNum, medItemNum, largeItemNum;

    public float spawnDelay = 2;
    private float nextSpawnTime;

    void Start(){
        smallItemNum = 0;
        medItemNum = 0;
        largeItemNum = 0;
    }

    // Update is called once per frame
    void Update()
    {
        
        spawnItem();

    }

    private void spawnItem(){
        //next spawn time
        nextSpawnTime = Time.time + spawnDelay;
        //creates the randome number gen that gives the position and item type
        var rnd = new System.Random();
        int itemNum = rnd.Next(1,4);
        int x = rnd.Next(-3 , 3);
        int z = rnd.Next(-3,0);

        Vector3 position = new Vector3(x, 0.41f ,z);

        //creates the item based on rng
        if (itemNum == 1 && smallItemNum < 3){
            Instantiate(smallItem, position,  Quaternion.identity);
            smallItemNum += 1; 
        }

        if (itemNum == 2 && medItemNum < 3){
            Instantiate(medItem, position,  Quaternion.identity);
            medItemNum += 1;  
        }
                
        if (itemNum == 3 && largeItemNum<3){
            Instantiate(largeItem, position,  Quaternion.identity);
            largeItemNum += 1;
        }
    }
}
